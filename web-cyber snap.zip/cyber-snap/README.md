# Cyber-Snap

A futuristic AI desktop assistant: a cyberpunk web UI with wake-word voice
control, backed by a local desktop agent that performs a fixed set of
permitted OS actions.

## Parts

- **frontend/** — browser UI (HTML/CSS/vanilla JS). Cyberpunk visual, wake
  word ("Hello Cyber-Snap", or "Cyber-Snap" once already listening), chat
  panel, settings drawer with per-permission toggles. No secrets live here.
- **agent/** — local desktop agent (Node.js, zero dependencies). The only
  component allowed to touch the OS. Runs on `http://127.0.0.1:8787`,
  requires a per-install token (`agent/token.txt`, generated on first run),
  enforces its own `permissions.json`, and only executes a fixed command
  registry (`agent/commands.js`).
- **server/** — local AI backend proxy (Node.js, zero dependencies) on
  `http://127.0.0.1:8788`. Owns the AI API key server-side via
  `server/.env`. Supports `anthropic`, `openai`, `gemini`, and `deepseek`
  providers via `server/aiProvider.js`.

## Running it (3 terminals)

**Terminal 1 — agent:**
```
cd agent
node server.js
```
Paste the printed token into Settings → Desktop Agent → Access token, then
click Connect / Verify. You need to do this again every time you restart
the agent (or generate a new token).

**Terminal 2 — AI backend:**
```
cd server
cp .env.example .env   # then fill in your real API key
node server.js
```

**Terminal 3 — frontend:**
```
cd frontend
python3 -m http.server 5500
```

Then open `http://localhost:5500` in Chrome (best Web Speech API support).

## Security notes

- The agent binds to `127.0.0.1` only — never exposed to the network.
- Every agent request requires the per-install token; the agent
  independently re-checks permissions server-side and never trusts the
  frontend's copy of that state.
- There is no generic "run this string" command — only a fixed allowlist
  in `agent/commands.js`.
- `UNLOCK_DEVICE` sends an Enter keystroke to dismiss a lock screen — this
  is only meaningful (and only safe) on a device with **no PIN, password,
  or biometric** configured. It does not, and cannot, bypass real
  authentication.
- Never paste real API keys or the agent token into chat, screenshots, or
  version control.

## Known limitations / things to keep an eye on

- Free-tier AI providers (Gemini, DeepSeek) have request quotas — Gemini's
  resets daily at midnight Pacific time; DeepSeek requires a small prepaid
  balance. Switching `AI_PROVIDER` in `.env` (then restarting the
  `server/` process) is the fastest way to work around a temporary outage
  on one provider.
- A few frontend files (`chat.js`, `permissions.js`, `css/style.css`) and
  `server/server.js` were reconstructed to match how the rest of the
  codebase calls them, since their original content wasn't available when
  this bundle was assembled — see the comment at the top of each for
  details, and replace with your originals if they differ.
