// intent.js — Command classification layer.
//
// IMPORTANT: this maps speech/text to a small, fixed set of predefined action
// names (see agent/commands.js for the matching registry). It never lets the
// AI generate or forward an arbitrary shell command. If nothing matches, the
// utterance is treated as a normal conversational request.

const COMMAND_PATTERNS = [
  { action: "OPEN_CHROME", permission: "openApplications", risk: "low",
    patterns: [/open (google )?chrome/, /launch chrome/] },
  { action: "OPEN_EDGE", permission: "openApplications", risk: "low",
    patterns: [/open edge/, /launch edge/] },
  { action: "OPEN_FIREFOX", permission: "openApplications", risk: "low",
    patterns: [/open firefox/, /launch firefox/] },
  { action: "OPEN_BROWSER", permission: "openApplications", risk: "low",
    patterns: [/open( the)? browser/] },
  { action: "OPEN_CALCULATOR", permission: "openApplications", risk: "low",
    patterns: [/open (the )?calculator/, /launch calculator/] },
  { action: "OPEN_NOTEPAD", permission: "openApplications", risk: "low",
    patterns: [/open notepad/, /open (a |the )?text editor/] },
  { action: "OPEN_FILE_EXPLORER", permission: "openApplications", risk: "low",
    patterns: [/open (file explorer|finder|files)/] },
  { action: "OPEN_TERMINAL", permission: "openApplications", risk: "low",
    patterns: [/open (the )?terminal/, /open (the )?(command prompt|powershell)/, /launch terminal/] },
  { action: "OPEN_CAMERA", permission: "openApplications", risk: "low",
    patterns: [/open (the )?camera/, /launch camera/] },
  { action: "OPEN_TASK_MANAGER", permission: "openApplications", risk: "low",
    patterns: [/open task manager/, /open activity monitor/] },
  { action: "TOGGLE_MUTE", permission: "openApplications", risk: "low",
    patterns: [/^(mute|unmute)( (my|the) (mic|audio|volume|sound))?$/, /toggle mute/] },
  { action: "SCREENSHOT", permission: "systemInfo", risk: "low",
    patterns: [/take a screenshot/, /screenshot/, /capture (the )?screen/] },

  { action: "LOCK_DEVICE", permission: "lockDevice", risk: "medium",
    patterns: [/lock (my |the )?(computer|laptop|pc|device|screen)/] },
  { action: "UNLOCK_DEVICE", permission: "unlockDevice", risk: "medium",
    patterns: [/unlock (my |the )?(pc|computer|screen|laptop|device)/, /wake (my |the )?(pc|screen|laptop)/] },
  { action: "LOGOUT", permission: "logoutDevice", risk: "medium",
    patterns: [/log ?out/, /sign out/] },

  { action: "RESTART", permission: "restartDevice", risk: "high",
    patterns: [/restart (my |the )?(computer|laptop|pc|device)/, /reboot/] },
  { action: "SHUTDOWN", permission: "shutdownDevice", risk: "high",
    patterns: [/shut ?down (my |the )?(computer|laptop|pc|device)/, /turn off (my |the )?(computer|laptop|pc)/] },

  { action: "SYSTEM_INFO", permission: "systemInfo", risk: "low",
    patterns: [
      /what (operating system|os) am i (using|running)/,
      /system info/,
      /what.?s my (os|operating system)/,
      /show (me )?system info/,
      /how'?s my (system|computer|pc) doing/,
    ] },
];

const Intent = {
  // Returns { type: 'desktop_action', action, permission, risk } or { type: 'conversation' }
  classify(text) {
    const t = text.trim().toLowerCase();
    for (const cmd of COMMAND_PATTERNS) {
      if (cmd.patterns.some((re) => re.test(t))) {
        return { type: "desktop_action", action: cmd.action, permission: cmd.permission, risk: cmd.risk };
      }
    }
    return { type: "conversation" };
  },

  friendlyActionName(action) {
    const map = {
      OPEN_CHROME: "Chrome", OPEN_EDGE: "Edge", OPEN_FIREFOX: "Firefox",
      OPEN_BROWSER: "your browser", OPEN_CALCULATOR: "Calculator", OPEN_NOTEPAD: "Notepad",
      OPEN_FILE_EXPLORER: "File Explorer", OPEN_TERMINAL: "Terminal", OPEN_CAMERA: "Camera",
      OPEN_TASK_MANAGER: "Task Manager", TOGGLE_MUTE: "mute toggle", SCREENSHOT: "screenshot",
      LOCK_DEVICE: "device lock", UNLOCK_DEVICE: "screen unlock", LOGOUT: "log out",
      RESTART: "restart", SHUTDOWN: "shutdown", SYSTEM_INFO: "system info",
    };
    return map[action] || action;
  },
};
