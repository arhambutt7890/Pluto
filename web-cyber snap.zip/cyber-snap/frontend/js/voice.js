// voice.js — wake-word detection + speech synthesis state machine.
//
// States: idle -> listening (for wake word) -> active (wake detected) ->
//         speaking (greeting/response) -> awake-listening (for a command) ->
//         processing -> speaking (result) -> listening
//
// Recognition is explicitly stopped before speaking and only restarted after
// speechSynthesis finishes, so Cyber-Snap never hears its own voice.
//
// A fresh SpeechRecognition instance is created on every (re)start, and all
// restarts go through scheduleStart(), which cancels any pending restart
// before scheduling a new one — this prevents two competing .start() calls
// from racing each other and throwing InvalidStateError.

const Voice = (() => {
  const SpeechRecognitionImpl = window.SpeechRecognition || window.webkitSpeechRecognition;
  let recognition = null;
  let state = "idle"; // idle | listening | active | speaking | awake-listening | processing
  let awakeWindowTimer = null;
  let restartTimer = null;
  let onWakeCallback = null;
  let onCommandCallback = null;
  let onStateChangeCallback = null;
  let manuallyStopped = false;

  function supported() {
    return !!SpeechRecognitionImpl && "speechSynthesis" in window;
  }

  function setState(next) {
    state = next;
    if (onStateChangeCallback) onStateChangeCallback(state);
  }

  function createRecognition() {
    const r = new SpeechRecognitionImpl();
    r.continuous = true;
    r.interimResults = false;
    r.lang = "en-US";

    r.onresult = (event) => {
      const transcript = event.results[event.results.length - 1][0].transcript.trim();
      handleTranscript(transcript);
    };

    r.onerror = (event) => {
      if (event.error !== "no-speech" && event.error !== "aborted") {
        console.warn("Speech recognition error:", event.error);
      }
    };

    r.onend = () => {
      // Only react if this is still the active instance — a stale instance
      // from a superseded attempt should never trigger its own restart.
      if (r !== recognition) return;
      if (!manuallyStopped && (state === "listening" || state === "awake-listening")) {
        scheduleStart(state, 250);
      }
    };

    return r;
  }

  // Centralized restart scheduler. Always cancels any previously pending
  // restart before scheduling a new one, so only ONE .start() call is ever
  // in flight at a time — this is what prevents the InvalidStateError race.
  function scheduleStart(targetState, delay = 150) {
    clearTimeout(restartTimer);
    restartTimer = setTimeout(() => {
      if (manuallyStopped) return;
      if (state !== targetState) return; // superseded by a later state change
      const r = createRecognition();
      recognition = r;
      try {
        r.start();
      } catch (err) {
        console.warn(`Recognition start failed (${targetState}):`, err);
      }
    }, delay);
  }

  function init({ onWake, onCommand, onStateChange }) {
    onWakeCallback = onWake;
    onCommandCallback = onCommand;
    onStateChangeCallback = onStateChange;

    if (!supported()) {
      setState("error");
      return false;
    }

    recognition = createRecognition();
    return true;
  }

  function handleTranscript(transcript) {
    const lower = transcript.toLowerCase();

    const isWake =
      lower.includes(CyberSnapConfig.WAKE_PHRASE) ||
      lower.includes(CyberSnapConfig.SECONDARY_WAKE_PHRASE);

    if (state === "listening" && isWake) {
      setState("active");
      stopRecognition();
      if (onWakeCallback) onWakeCallback();
      return;
    }

    if (state === "awake-listening") {
      clearTimeout(awakeWindowTimer);
      setState("processing");
      stopRecognition();
      if (onCommandCallback) onCommandCallback(transcript);
      return;
    }

    // Ignore transcripts while idle/speaking/processing/error.
  }

  function startListeningForWake() {
    manuallyStopped = false;
    setState("listening");
    scheduleStart("listening");
  }

  function startListeningForCommand(timeoutMs = 8000) {
    manuallyStopped = false;
    setState("awake-listening");
    scheduleStart("awake-listening");
    clearTimeout(awakeWindowTimer);
    awakeWindowTimer = setTimeout(() => {
      if (state === "awake-listening") {
        stopRecognition();
        setState("listening");
        startListeningForWake();
      }
    }, timeoutMs);
  }

  function stopRecognition() {
    manuallyStopped = true;
    clearTimeout(restartTimer);
    if (recognition) {
      try { recognition.stop(); } catch (err) { /* not running — expected sometimes */ }
    }
  }

  function speak(text, { thenState = "listening", thenListenForCommand = false } = {}) {
    stopRecognition();
    setState("speaking");

    const utter = new SpeechSynthesisUtterance(text);
    utter.rate = 1.02;
    utter.pitch = 1.0;

    utter.onend = () => {
      if (thenListenForCommand) {
        startListeningForCommand();
      } else if (thenState === "listening") {
        startListeningForWake();
      } else {
        setState(thenState);
      }
    };
    utter.onerror = () => {
      startListeningForWake();
    };

    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(utter);
  }

  function getState() {
    return state;
  }

  return { supported, init, startListeningForWake, startListeningForCommand, stopRecognition, speak, getState };
})();
