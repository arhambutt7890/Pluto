// app.js — boots Cyber-Snap and wires all the modules together.

(function () {
  const coreEl = document.getElementById("core");
  const coreCaptionEl = document.getElementById("coreCaption");
  const chatLogEl = document.getElementById("chatLog");
  const chatFormEl = document.getElementById("chatForm");
  const chatInputEl = document.getElementById("chatInput");
  const micBtn = document.getElementById("micBtn");
  const micPill = document.getElementById("micStatusPill");
  const agentPill = document.getElementById("agentStatusPill");
  const userGreetName = document.getElementById("userGreetName");

  const settingsBtn = document.getElementById("settingsBtn");
  const closeDrawerBtn = document.getElementById("closeDrawerBtn");
  const drawer = document.getElementById("settingsDrawer");
  const backdrop = document.getElementById("drawerBackdrop");
  const userNameInput = document.getElementById("userNameInput");
  const saveNameBtn = document.getElementById("saveNameBtn");
  const agentUrlInput = document.getElementById("agentUrlInput");
  const agentTokenInput = document.getElementById("agentTokenInput");
  const connectAgentBtn = document.getElementById("connectAgentBtn");
  const agentHint = document.getElementById("agentHint");
  const permissionsListEl = document.getElementById("permissionsList");

  Chat.init(chatLogEl);

  // ---------- Identity ----------
  function getUserName() {
    return Store.get(CyberSnapConfig.STORAGE_KEYS.userName, "");
  }
  function refreshNameUI() {
    const name = getUserName();
    userGreetName.textContent = name ? name : "no name set";
    userNameInput.value = name;
  }
  refreshNameUI();

  saveNameBtn.addEventListener("click", () => {
    Store.set(CyberSnapConfig.STORAGE_KEYS.userName, userNameInput.value.trim());
    refreshNameUI();
    Chat.system("Name saved.");
  });

  // ---------- Settings drawer ----------
  function openDrawer() {
    drawer.classList.add("open");
    backdrop.classList.add("open");
    agentUrlInput.value = AgentClient.getUrl();
    agentTokenInput.value = AgentClient.getToken();
    Permissions.renderInto(permissionsListEl);
    refreshAgentStatus();
  }
  function closeDrawer() {
    drawer.classList.remove("open");
    backdrop.classList.remove("open");
  }
  settingsBtn.addEventListener("click", openDrawer);
  closeDrawerBtn.addEventListener("click", closeDrawer);
  backdrop.addEventListener("click", closeDrawer);

  connectAgentBtn.addEventListener("click", async () => {
    AgentClient.setUrl(agentUrlInput.value.trim() || CyberSnapConfig.DEFAULT_AGENT_URL);
    AgentClient.setToken(agentTokenInput.value.trim());
    await refreshAgentStatus();
  });

  async function refreshAgentStatus() {
    const status = await AgentClient.checkStatus();
    if (status.connected) {
      agentPill.dataset.state = "connected";
      agentPill.querySelector(".label").textContent = "Agent: Connected";
      agentHint.textContent = "Desktop Agent Connected.";
    } else {
      agentPill.dataset.state = "disconnected";
      agentPill.querySelector(".label").textContent = "Agent: Disconnected";
      agentHint.textContent = "Cyber-Snap Desktop Agent is not connected. Start it locally (see agent/README) then click Connect / Verify.";
    }
    return status;
  }

  // ---------- Core visual state ----------
  function setCoreState(state, caption) {
    coreEl.dataset.state = state;
    if (caption) coreCaptionEl.textContent = caption;
  }

  function setMicPill(state, label) {
    micPill.dataset.state = state;
    micPill.querySelector(".label").textContent = `Mic: ${label}`;
    micBtn.dataset.active = state === "listening" || state === "awake-listening" ? "true" : "false";
  }

  // ---------- Command execution (shared by voice + text input) ----------
  async function handleUserUtterance(text, { speakReplies }) {
    Chat.user(text);
    const intent = Intent.classify(text);

    if (intent.type === "desktop_action") {
      await runDesktopAction(intent, speakReplies);
      return;
    }

    setCoreState("processing", "Thinking…");
    const reply = await AiProvider.chat(Chat.history);
    Chat.assistant(reply);
    if (speakReplies) {
      Voice.speak(reply, { thenState: "listening" });
    } else {
      setCoreState("idle", 'Say "Hello Cyber-Snap"');
    }
  }

  async function runDesktopAction(intent, speakReplies) {
    // Fast local permission pre-check for a snappy UX message; the agent re-checks server-side.
    if (!Permissions.isEnabled(intent.permission)) {
      const msg = `${capitalize(Intent.friendlyActionName(intent.action))} permission is currently disabled. You can enable it from Cyber-Snap settings.`;
      Chat.assistant(msg);
      if (speakReplies) Voice.speak(msg, { thenState: "listening" }); else setCoreState("idle", 'Say "Hello Cyber-Snap"');
      return;
    }

    if (intent.risk === "high") {
      const confirmMsg = `Are you sure you want me to ${describeAction(intent.action)}? Say or type "yes" to confirm.`;
      Chat.assistant(confirmMsg);
      pendingHighRiskAction = intent;
      if (speakReplies) {
        Voice.speak(confirmMsg, { thenState: "awake-listening", thenListenForCommand: true });
      } else {
        setCoreState("active", "Waiting for confirmation…");
      }
      return;
    }

    await executeAction(intent.action, speakReplies);
  }

  let pendingHighRiskAction = null;

  async function executeAction(action, speakReplies, { confirm = false } = {}) {
    setCoreState("processing", `Running ${Intent.friendlyActionName(action)}…`);
    const result = await AgentClient.sendCommand(action, { confirm });
    const msg = result.message || (result.success ? "Done." : "That didn't work.");
    Chat.assistant(msg);
    if (speakReplies) {
      Voice.speak(msg, { thenState: "listening" });
    } else {
      setCoreState("idle", 'Say "Hello Cyber-Snap"');
    }
  }

  function describeAction(action) {
    if (action === "SHUTDOWN") return "shut down the computer";
    if (action === "RESTART") return "restart the computer";
    return `run ${Intent.friendlyActionName(action)}`;
  }
  function capitalize(s) { return s.charAt(0).toUpperCase() + s.slice(1); }

  // Intercept "yes"/"no" replies while a high-risk confirmation is pending.
  function isConfirmation(text) {
    return /^\s*(yes|yeah|yep|confirm|do it)\s*\.?\s*$/i.test(text);
  }
  function isDenial(text) {
    return /^\s*(no|nope|cancel|don't|stop)\s*\.?\s*$/i.test(text);
  }

  async function handleAnyUtterance(text, { speakReplies }) {
    if (pendingHighRiskAction) {
      const action = pendingHighRiskAction;
      if (isConfirmation(text)) {
        pendingHighRiskAction = null;
        Chat.user(text);
        await executeAction(action.action, speakReplies, { confirm: true });
        return;
      }
      if (isDenial(text)) {
        pendingHighRiskAction = null;
        Chat.user(text);
        const msg = "Okay, cancelled.";
        Chat.assistant(msg);
        if (speakReplies) Voice.speak(msg, { thenState: "listening" }); else setCoreState("idle", 'Say "Hello Cyber-Snap"');
        return;
      }
      // Anything else while a confirmation is pending: drop the pending action and
      // process normally, so the assistant doesn't get stuck.
      pendingHighRiskAction = null;
    }
    await handleUserUtterance(text, { speakReplies });
  }

  // ---------- Voice wiring ----------
  const voiceReady = Voice.init({
    onStateChange(state) {
      const map = {
        idle: ["idle", "Idle"],
        listening: ["listening", "Listening"],
        active: ["active", "Active"],
        speaking: ["speaking", "Speaking"],
        "awake-listening": ["listening", "Listening"],
        processing: ["active", "Processing"],
        error: ["error", "Error"],
      };
      const [pillState, label] = map[state] || ["idle", "Idle"];
      setMicPill(pillState, label);
      if (state === "listening") setCoreState("listening", 'Say "Hello Cyber-Snap"');
      if (state === "active") setCoreState("active", "Activated");
      if (state === "speaking") setCoreState("speaking", "Speaking…");
      if (state === "awake-listening") setCoreState("active", "Listening for your command…");
    },
    onWake() {
      const name = getUserName();
      const greeting = name
        ? `Hello Mister ${name}, how can I help you?`
        : "Hello, how can I help you? You can set your name in settings.";
      Chat.assistant(greeting);
      Voice.speak(greeting, { thenState: "awake-listening", thenListenForCommand: true });
    },
    async onCommand(transcript) {
      await handleAnyUtterance(transcript, { speakReplies: true });
    },
  });

  if (voiceReady) {
    Voice.startListeningForWake();
  } else {
    setMicPill("error", "Unsupported");
    Chat.system("Voice recognition isn't supported in this browser. You can still type to Cyber-Snap.");
  }

  micBtn.addEventListener("click", () => {
    const state = Voice.getState();
    if (state === "listening") {
      Voice.startListeningForCommand();
      setCoreState("active", "Listening for your command…");
    } else if (state === "awake-listening") {
      Voice.stopRecognition();
      Voice.startListeningForWake();
    }
  });

  // ---------- Text input ----------
  chatFormEl.addEventListener("submit", async (e) => {
    e.preventDefault();
    const text = chatInputEl.value.trim();
    if (!text) return;
    chatInputEl.value = "";
    await handleAnyUtterance(text, { speakReplies: false });
  });

  // ---------- Boot ----------
  refreshAgentStatus();
  setInterval(refreshAgentStatus, 15000);
})();
