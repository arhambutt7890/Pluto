// agentClient.js — talks ONLY to the local desktop agent (never to the OS directly).
// The agent is the sole component allowed to touch the operating system.

const AgentClient = {
  getUrl() {
    return Store.get(CyberSnapConfig.STORAGE_KEYS.agentUrl, CyberSnapConfig.DEFAULT_AGENT_URL);
  },
  setUrl(url) {
    Store.set(CyberSnapConfig.STORAGE_KEYS.agentUrl, url);
  },
  getToken() {
    return Store.get(CyberSnapConfig.STORAGE_KEYS.agentToken, "");
  },
  setToken(token) {
    Store.set(CyberSnapConfig.STORAGE_KEYS.agentToken, token);
  },

  async checkStatus() {
    try {
      const res = await fetch(`${this.getUrl()}/status`, { method: "GET" });
      if (!res.ok) return { connected: false };
      const data = await res.json();
      return { connected: true, ...data };
    } catch {
      return { connected: false };
    }
  },

  async getPermissions() {
    try {
      const res = await fetch(`${this.getUrl()}/permissions`, {
        method: "GET",
        headers: { "X-CyberSnap-Token": this.getToken() },
      });
      if (!res.ok) return null;
      return await res.json();
    } catch {
      return null;
    }
  },

  async setPermissions(perms) {
    try {
      const res = await fetch(`${this.getUrl()}/permissions`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-CyberSnap-Token": this.getToken(),
        },
        body: JSON.stringify(perms),
      });
      if (!res.ok) return null;
      return await res.json();
    } catch {
      return null;
    }
  },

  // Sends a predefined command name to the agent. The agent independently
  // re-validates the permission and risk level — the frontend check is only
  // for a fast, friendly UX response, never the actual security boundary.
  async sendCommand(action, { confirm = false } = {}) {
    try {
      const res = await fetch(`${this.getUrl()}/command`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-CyberSnap-Token": this.getToken(),
        },
        body: JSON.stringify({ action, confirm }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        return { success: false, action, message: data.message || `Agent error (${res.status}).` };
      }
      return data;
    } catch (err) {
      return { success: false, action, message: "Desktop Agent is not connected." };
    }
  },
};
