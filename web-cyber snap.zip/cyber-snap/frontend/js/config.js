// config.js — shared constants and small storage helpers.
// No secrets live here. The AI API key never touches the browser (see server/).

const CyberSnapConfig = {
  WAKE_PHRASE: "hello cyber snap",
  SECONDARY_WAKE_PHRASE: "cyber snap", // shorter re-activation phrase once listening has started
  STORAGE_KEYS: {
    userName: "cybersnap.userName",
    agentUrl: "cybersnap.agentUrl",
    agentToken: "cybersnap.agentToken",
    permissions: "cybersnap.permissions",
    aiBackendUrl: "cybersnap.aiBackendUrl",
    history: "cybersnap.history",
  },
  DEFAULT_AGENT_URL: "http://127.0.0.1:8787",
  DEFAULT_AI_BACKEND_URL: "http://127.0.0.1:8788",
};

const Store = {
  get(key, fallback = null) {
    try {
      const raw = localStorage.getItem(key);
      if (raw === null) return fallback;
      return JSON.parse(raw);
    } catch {
      return fallback;
    }
  },
  set(key, value) {
    localStorage.setItem(key, JSON.stringify(value));
  },
};
