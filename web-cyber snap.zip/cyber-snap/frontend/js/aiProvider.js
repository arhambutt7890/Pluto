// aiProvider.js — the frontend NEVER holds an API key. It calls a local backend
// route which owns the real AI provider call. If that backend isn't running,
// Cyber-Snap falls back to a small set of canned, clearly-labeled responses
// so the demo still works end to end.
//
// Creator/developer questions are answered locally with a fixed string,
// bypassing the AI call entirely — this guarantees exact, consistent wording
// whether or not the backend/AI provider is reachable.

const CREATOR_PATTERNS = [
  /who (made|created|built|developed) you/,
  /who is your (developer|creator|owner|maker)/,
  /who'?s your (developer|creator|owner|maker)/,
  /who owns you/,
];

const CREATOR_ANSWER = "I was created by Muhammad Arham Butt.";

const AiProvider = {
  getBackendUrl() {
    return Store.get(CyberSnapConfig.STORAGE_KEYS.aiBackendUrl, CyberSnapConfig.DEFAULT_AI_BACKEND_URL);
  },

  _isCreatorQuestion(text) {
    const lower = (text || "").toLowerCase();
    return CREATOR_PATTERNS.some((re) => re.test(lower));
  },

  async chat(history) {
    // history: array of {role: 'user'|'assistant', content: string}
    const lastUserMessage = history[history.length - 1]?.content || "";

    if (this._isCreatorQuestion(lastUserMessage)) {
      return CREATOR_ANSWER;
    }

    try {
      const res = await fetch(`${this.getBackendUrl()}/api/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: history }),
      });
      if (!res.ok) throw new Error(`backend ${res.status}`);
      const data = await res.json();
      return data.reply || "…";
    } catch {
      return this._fallback(history);
    }
  },

  _fallback(history) {
    const last = (history[history.length - 1]?.content || "").toLowerCase();
    if (!last) return "I'm listening.";
    if (this._isCreatorQuestion(last)) {
      return CREATOR_ANSWER;
    }
    if (last.includes("what can you do")) {
      return "I can answer questions, open supported applications, and perform permitted system actions. Right now I'm running without an AI backend connected, so my conversation is limited — start the Cyber-Snap server to unlock full AI replies.";
    }
    if (last.includes("who are you")) {
      return "I'm Cyber-Snap, your desktop assistant.";
    }
    return "The AI service isn't connected right now, so I can't give you a full answer to that — but I can still open apps and run permitted system commands.";
  },
};
