// permissions.js — RECONSTRUCTED FILE.
// This file was never pasted into the chat that produced this project, so it
// is rebuilt here to match app.js's Permissions.isEnabled()/renderInto() calls
// and the exact permission keys used by agent/server.js's DEFAULT_PERMISSIONS.
// Swap in your real version if it differs from this reconstruction.
//
// The agent is the real enforcement point (see agent/server.js) — this is
// only a local cache for fast UX checks and for rendering the Settings toggles.

const PERMISSION_DEFS = [
  { key: "voiceRecognition", label: "Voice Recognition", desc: "Allow wake-word listening and voice commands." },
  { key: "aiConversation", label: "AI Conversation", desc: "Allow sending your messages to the configured AI provider." },
  { key: "openApplications", label: "Open Applications", desc: "Allow opening apps like Chrome, Calculator, Terminal, etc." },
  { key: "lockDevice", label: "Lock Device", desc: "Allow locking the screen." },
  { key: "unlockDevice", label: "Unlock Device", desc: "Allow waking/dismissing the lock screen (only meaningful if your device has no PIN/password)." },
  { key: "logoutDevice", label: "Log Out", desc: "Allow signing out of the current session." },
  { key: "restartDevice", label: "Restart Device", desc: "Allow restarting the computer (requires confirmation)." },
  { key: "shutdownDevice", label: "Shutdown Device", desc: "Allow shutting down the computer (requires confirmation)." },
  { key: "fileAccess", label: "File Access", desc: "Reserved for future file-related commands." },
  { key: "systemInfo", label: "System Info", desc: "Allow reading basic system info and taking screenshots." },
];

const Permissions = (() => {
  let cache = {};

  function isEnabled(key) {
    return !!cache[key];
  }

  async function renderInto(container) {
    container.innerHTML = "";

    const remote = await AgentClient.getPermissions();
    if (remote) {
      cache = remote;
    }

    PERMISSION_DEFS.forEach((def) => {
      const row = document.createElement("div");
      row.className = "permission-row";

      const text = document.createElement("div");
      text.className = "permission-text";
      const title = document.createElement("div");
      title.className = "permission-title";
      title.textContent = def.label;
      const desc = document.createElement("div");
      desc.className = "permission-desc";
      desc.textContent = def.desc;
      text.appendChild(title);
      text.appendChild(desc);

      const toggle = document.createElement("label");
      toggle.className = "switch";
      const input = document.createElement("input");
      input.type = "checkbox";
      input.checked = !!cache[def.key];
      input.addEventListener("change", async () => {
        const next = { ...cache, [def.key]: input.checked };
        const saved = await AgentClient.setPermissions({ [def.key]: input.checked });
        cache = saved || next;
      });
      const slider = document.createElement("span");
      slider.className = "slider";
      toggle.appendChild(input);
      toggle.appendChild(slider);

      row.appendChild(text);
      row.appendChild(toggle);
      container.appendChild(row);
    });
  }

  return { isEnabled, renderInto };
})();
