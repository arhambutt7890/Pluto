// chat.js — RECONSTRUCTED FILE.
// This file was never pasted into the chat that produced this project, so it
// is rebuilt here to match exactly how app.js calls it: Chat.init(el),
// Chat.user(text), Chat.assistant(text), Chat.system(text), and Chat.history
// as an array of {role, content} consumed directly by AiProvider.chat().
// Swap in your real version if it differs from this reconstruction.

const Chat = (() => {
  let logEl = null;
  const history = []; // array of {role: 'user'|'assistant', content: string}

  function init(el) {
    logEl = el;
  }

  function scrollToBottom() {
    if (logEl) logEl.scrollTop = logEl.scrollHeight;
  }

  function renderBubble(role, text) {
    if (!logEl) return;
    const wrap = document.createElement("div");
    wrap.className = `msg msg-${role}`;

    const label = document.createElement("div");
    label.className = "msg-label";
    label.textContent = role === "user" ? "YOU" : role === "assistant" ? "CYBER-SNAP" : "SYSTEM";

    const body = document.createElement("div");
    body.className = "msg-body";
    body.textContent = text;

    wrap.appendChild(label);
    wrap.appendChild(body);
    logEl.appendChild(wrap);
    scrollToBottom();
  }

  function user(text) {
    history.push({ role: "user", content: text });
    renderBubble("user", text);
  }

  function assistant(text) {
    history.push({ role: "assistant", content: text });
    renderBubble("assistant", text);
  }

  function system(text) {
    // System/status messages are shown in the log but not sent to the AI as history.
    renderBubble("system", text);
  }

  return {
    init,
    user,
    assistant,
    system,
    get history() {
      return history;
    },
  };
})();
