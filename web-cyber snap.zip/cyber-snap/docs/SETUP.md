# Setup

## Requirements

- Node.js (any reasonably recent version)
- Python 3 (only used to serve the frontend's static files — any static
  file server works if you'd rather use something else)
- Google Chrome (best support for the Web Speech API used for wake-word
  detection and voice replies)

## First-time setup

1. Clone/copy this project.
2. In `server/`, copy `.env.example` to `.env` and fill in a real API key
   for whichever provider you're using (`gemini`, `deepseek`, `openai`,
   or `anthropic`). Never commit or share this file.
3. Start all three parts (see README.md's "Running it" section).
4. On first agent startup, it generates `agent/token.txt` and prints the
   token to the console. Copy that token into the app's
   Settings → Desktop Agent → Access token field, then click
   Connect / Verify.
5. In Settings → Permissions, enable whichever actions you want available
   (all default to off except `voiceRecognition`, `aiConversation`,
   `openApplications`, and `systemInfo`).

## Every time you restart the agent

Generating a new terminal session for `agent/` does **not** regenerate the
token (it persists in `agent/token.txt`), but the frontend's copy of the
Agent status still needs to be re-verified — click
Connect / Verify again after every agent restart.

## Common issues

- **"Unauthorized" on every command** — almost always means
  Connect / Verify was never clicked after the token was last generated
  or changed. Check Local Storage (`cybersnap.agentToken`) in dev tools to
  confirm the token was actually saved.
- **"AI service isn't connected"** — check the `server/` terminal for the
  actual error. Usually one of: `.env` not filled in, wrong/expired API
  key, a deprecated model name, or a rate limit / quota / balance issue
  with the provider.
- **Mic does nothing** — check Windows Sound Settings has a working input
  device selected, and that Chrome's site permissions
  (`chrome://settings/content/microphone`) allow `localhost:5500`.
