// server.js — Cyber-Snap Desktop Agent.
//
// This is the ONLY process in the whole project allowed to touch the operating
// system. It:
//   - binds to 127.0.0.1 only (never 0.0.0.0) — not reachable from the network
//   - requires a per-install secret token on every request
//   - only executes commands from the fixed registry in commands.js
//   - independently enforces the permission + confirmation rules (never trusts
//     the frontend's copy of that state)
//   - logs every executed action to agent/logs.txt
//
// Run with: node server.js   (see ../docs/SETUP.md)

"use strict";

const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { COMMANDS } = require("./commands");

const PORT = process.env.CYBERSNAP_AGENT_PORT || 8787;
const HOST = "127.0.0.1"; // localhost only — do not change to 0.0.0.0
const TOKEN_FILE = path.join(__dirname, "token.txt");
const PERMISSIONS_FILE = path.join(__dirname, "permissions.json");
const LOG_FILE = path.join(__dirname, "logs.txt");

// ---------- Token bootstrap ----------
function getOrCreateToken() {
  if (fs.existsSync(TOKEN_FILE)) {
    return fs.readFileSync(TOKEN_FILE, "utf8").trim();
  }
  const token = crypto.randomBytes(24).toString("hex");
  fs.writeFileSync(TOKEN_FILE, token, { mode: 0o600 });
  return token;
}
const AGENT_TOKEN = getOrCreateToken();

// ---------- Permission store (agent's own copy — the real enforcement point) ----------
const DEFAULT_PERMISSIONS = {
  voiceRecognition: true,
  aiConversation: true,
  openApplications: true,
  lockDevice: false,
  unlockDevice: false,
  logoutDevice: false,
  restartDevice: false,
  shutdownDevice: false,
  fileAccess: false,
  systemInfo: true,
};

function loadPermissions() {
  if (fs.existsSync(PERMISSIONS_FILE)) {
    try {
      return { ...DEFAULT_PERMISSIONS, ...JSON.parse(fs.readFileSync(PERMISSIONS_FILE, "utf8")) };
    } catch {
      return { ...DEFAULT_PERMISSIONS };
    }
  }
  fs.writeFileSync(PERMISSIONS_FILE, JSON.stringify(DEFAULT_PERMISSIONS, null, 2));
  return { ...DEFAULT_PERMISSIONS };
}
function savePermissions(perms) {
  fs.writeFileSync(PERMISSIONS_FILE, JSON.stringify(perms, null, 2));
}

function log(line) {
  const entry = `[${new Date().toISOString()}] ${line}\n`;
  fs.appendFile(LOG_FILE, entry, () => {});
  console.log(entry.trim());
}

// ---------- HTTP helpers ----------
function sendJson(res, status, body) {
  const data = JSON.stringify(body);
  res.writeHead(status, {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*", // local-only server; browser same-origin not guaranteed for file:// UIs
    "Access-Control-Allow-Headers": "Content-Type, X-CyberSnap-Token",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  });
  res.end(data);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let raw = "";
    req.on("data", (chunk) => {
      raw += chunk;
      if (raw.length > 1e6) req.destroy(); // guard against absurd payloads
    });
    req.on("end", () => {
      if (!raw) return resolve({});
      try { resolve(JSON.parse(raw)); } catch (e) { reject(e); }
    });
    req.on("error", reject);
  });
}

function isAuthorized(req) {
  const header = req.headers["x-cybersnap-token"];
  return typeof header === "string" && header.length > 0 && header === AGENT_TOKEN;
}

// ---------- Request handling ----------
const server = http.createServer(async (req, res) => {
  if (req.method === "OPTIONS") return sendJson(res, 204, {});

  const url = new URL(req.url, `http://${HOST}:${PORT}`);

  // /status is intentionally unauthenticated (so the UI can show "disconnected"
  // vs "found but not authorized" without already having the token) but reveals
  // nothing sensitive.
  if (url.pathname === "/status" && req.method === "GET") {
    return sendJson(res, 200, { connected: true, platform: process.platform, version: "1.0.0" });
  }

  if (url.pathname === "/permissions" && req.method === "GET") {
    if (!isAuthorized(req)) return sendJson(res, 401, { message: "Unauthorized." });
    return sendJson(res, 200, loadPermissions());
  }

  if (url.pathname === "/permissions" && req.method === "POST") {
    if (!isAuthorized(req)) return sendJson(res, 401, { message: "Unauthorized." });
    try {
      const body = await readBody(req);
      const current = loadPermissions();
      const next = { ...current };
      for (const key of Object.keys(DEFAULT_PERMISSIONS)) {
        if (typeof body[key] === "boolean") next[key] = body[key];
      }
      savePermissions(next);
      log(`Permissions updated: ${JSON.stringify(next)}`);
      return sendJson(res, 200, next);
    } catch {
      return sendJson(res, 400, { message: "Invalid request body." });
    }
  }

  if (url.pathname === "/command" && req.method === "POST") {
    if (!isAuthorized(req)) return sendJson(res, 401, { message: "Unauthorized." });

    let body;
    try {
      body = await readBody(req);
    } catch {
      return sendJson(res, 400, { message: "Invalid request body." });
    }

    const { action, confirm } = body;
    const command = COMMANDS[action];

    if (!command) {
      log(`Rejected unknown action: ${action}`);
      return sendJson(res, 400, { success: false, action, message: "Unknown or unsupported command." });
    }

    const perms = loadPermissions();
    if (!perms[command.permission]) {
      log(`Rejected (permission disabled) action: ${action}`);
      return sendJson(res, 403, { success: false, action, message: "Permission not enabled." });
    }

    if (command.requiresConfirm && !confirm) {
      return sendJson(res, 409, { success: false, action, message: "Confirmation required." });
    }

    try {
      const extra = await command.exec();
      log(`Executed action: ${action}`);
      return sendJson(res, 200, {
        success: true,
        action,
        message: typeof extra === "string" ? extra : command.label,
      });
    } catch (err) {
      log(`Failed action: ${action} — ${err.message}`);
      return sendJson(res, 500, { success: false, action, message: "The action could not be completed." });
    }
  }

  sendJson(res, 404, { message: "Not found." });
});

server.listen(PORT, HOST, () => {
  console.log("=========================================================");
  console.log(" CYBER-SNAP DESKTOP AGENT");
  console.log(` Listening on http://${HOST}:${PORT} (localhost only)`);
  console.log(` Access token: ${AGENT_TOKEN}`);
  console.log(" Paste this token into Cyber-Snap → Settings → Desktop Agent.");
  console.log(" Never share this token or expose this server to a network.");
  console.log("=========================================================");
});
