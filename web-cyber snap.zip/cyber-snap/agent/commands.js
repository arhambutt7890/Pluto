// commands.js — the ONE allowlist of OS actions the agent will ever perform.
//
// There is deliberately no generic "run this string" command. Every entry maps
// a fixed action name to a fixed, per-platform launch call. The AI / frontend
// can only ever ask for one of these names — see SECURITY.md.

"use strict";

const { spawn, exec } = require("child_process");
const os = require("os");
const path = require("path");

const platform = os.platform(); // 'win32' | 'darwin' | 'linux'

function open(cmdByPlatform) {
  return () =>
    new Promise((resolve, reject) => {
      const cmd = cmdByPlatform[platform];
      if (!cmd) return reject(new Error(`Unsupported on this platform (${platform}).`));
      const child = spawn(cmd.bin, cmd.args || [], { detached: true, stdio: "ignore" });
      child.on("error", reject);
      child.unref();
      resolve();
    });
}

function run(cmdByPlatform) {
  return () =>
    new Promise((resolve, reject) => {
      const cmd = cmdByPlatform[platform];
      if (!cmd) return reject(new Error(`Unsupported on this platform (${platform}).`));
      exec(cmd, (err) => (err ? reject(err) : resolve()));
    });
}

// risk: 'low' | 'medium' | 'high'
// permission: must match a key in the frontend's PERMISSION_DEFS (permissions.js)
const COMMANDS = {
  OPEN_CHROME: {
    risk: "low", permission: "openApplications", label: "Opening Chrome.",
    exec: open({
      win32: { bin: "cmd", args: ["/c", "start", "chrome"] },
      darwin: { bin: "open", args: ["-a", "Google Chrome"] },
      linux: { bin: "google-chrome", args: [] },
    }),
  },
  OPEN_EDGE: {
    risk: "low", permission: "openApplications", label: "Opening Edge.",
    exec: open({
      win32: { bin: "cmd", args: ["/c", "start", "msedge"] },
      darwin: { bin: "open", args: ["-a", "Microsoft Edge"] },
      linux: { bin: "microsoft-edge", args: [] },
    }),
  },
  OPEN_FIREFOX: {
    risk: "low", permission: "openApplications", label: "Opening Firefox.",
    exec: open({
      win32: { bin: "cmd", args: ["/c", "start", "firefox"] },
      darwin: { bin: "open", args: ["-a", "Firefox"] },
      linux: { bin: "firefox", args: [] },
    }),
  },
  OPEN_BROWSER: {
    risk: "low", permission: "openApplications", label: "Opening your browser.",
    exec: open({
      win32: { bin: "cmd", args: ["/c", "start", "https://"] },
      darwin: { bin: "open", args: ["https://"] },
      linux: { bin: "xdg-open", args: ["https://"] },
    }),
  },
  OPEN_CALCULATOR: {
    risk: "low", permission: "openApplications", label: "Opening Calculator.",
    exec: open({
      win32: { bin: "calc", args: [] },
      darwin: { bin: "open", args: ["-a", "Calculator"] },
      linux: { bin: "gnome-calculator", args: [] },
    }),
  },
  OPEN_NOTEPAD: {
    risk: "low", permission: "openApplications", label: "Opening Notepad.",
    exec: open({
      win32: { bin: "notepad", args: [] },
      darwin: { bin: "open", args: ["-a", "TextEdit"] },
      linux: { bin: "gedit", args: [] },
    }),
  },
  OPEN_FILE_EXPLORER: {
    risk: "low", permission: "openApplications", label: "Opening File Explorer.",
    exec: open({
      win32: { bin: "explorer", args: ["."] },
      darwin: { bin: "open", args: ["."] },
      linux: { bin: "xdg-open", args: ["."] },
    }),
  },
  OPEN_TERMINAL: {
    risk: "low", permission: "openApplications", label: "Opening Terminal.",
    exec: open({
      win32: { bin: "cmd", args: ["/c", "start", "powershell"] },
      darwin: { bin: "open", args: ["-a", "Terminal"] },
      linux: { bin: "x-terminal-emulator", args: [] },
    }),
  },
  OPEN_CAMERA: {
    risk: "low", permission: "openApplications", label: "Opening Camera.",
    exec: open({
      win32: { bin: "cmd", args: ["/c", "start", "microsoft.windows.camera:"] },
      darwin: { bin: "open", args: ["-a", "Photo Booth"] },
      linux: { bin: "cheese", args: [] },
    }),
  },
  OPEN_TASK_MANAGER: {
    risk: "low", permission: "openApplications", label: "Opening Task Manager.",
    exec: open({
      win32: { bin: "taskmgr", args: [] },
      darwin: { bin: "open", args: ["-a", "Activity Monitor"] },
      linux: { bin: "gnome-system-monitor", args: [] },
    }),
  },
  TOGGLE_MUTE: {
    risk: "low", permission: "openApplications", label: "Toggled mute.",
    exec: run({
      win32: "powershell -c \"(New-Object -ComObject WScript.Shell).SendKeys([char]173)\"",
      darwin: "osascript -e 'set volume output muted (not (output muted of (get volume settings)))'",
      linux: "amixer -q set Master toggle",
    }),
  },
  SCREENSHOT: {
    risk: "low", permission: "systemInfo", label: "Screenshot taken.",
    exec: () =>
      new Promise((resolve, reject) => {
        const desktop = path.join(os.homedir(), "Desktop");
        const filename = `cybersnap-screenshot-${Date.now()}.png`;
        const filepath = path.join(desktop, filename);

        const scripts = {
          win32:
            `powershell -c "Add-Type -AssemblyName System.Windows.Forms,System.Drawing; ` +
            `$b=[System.Windows.Forms.SystemInformation]::VirtualScreen; ` +
            `$bmp=New-Object System.Drawing.Bitmap $b.Width,$b.Height; ` +
            `$g=[System.Drawing.Graphics]::FromImage($bmp); ` +
            `$g.CopyFromScreen($b.Left,$b.Top,0,0,$bmp.Size); ` +
            `$bmp.Save('${filepath}')"`,
          darwin: `screencapture -x "${filepath}"`,
          linux: `import -window root "${filepath}"`,
        };

        const cmd = scripts[platform];
        if (!cmd) return reject(new Error(`Unsupported on this platform (${platform}).`));

        exec(cmd, (err) => {
          if (err) return reject(err);
          resolve(`Screenshot saved to Desktop as ${filename}.`);
        });
      }),
  },

  LOCK_DEVICE: {
    risk: "medium", permission: "lockDevice", label: "Locking the device.",
    exec: run({
      win32: "rundll32.exe user32.dll,LockWorkStation",
      darwin: "pmset displaysleepnow",
      linux: "loginctl lock-session || xdg-screensaver lock",
    }),
  },
  UNLOCK_DEVICE: {
    risk: "medium", permission: "unlockDevice", label: "Waking the screen.",
    exec: run({
      win32:
        `powershell -c "` +
        `Add-Type -AssemblyName System.Windows.Forms; ` +
        `[System.Windows.Forms.Cursor]::Position = [System.Windows.Forms.Cursor]::Position; ` +
        `Start-Sleep -Milliseconds 300; ` +
        `$sig='[DllImport(\\"user32.dll\\")]public static extern void mouse_event(int f,int x,int y,int d,int e);'; ` +
        `Add-Type -MemberDefinition $sig -Name U -Namespace W; ` +
        `[W.U]::mouse_event(1,1,0,0,0); [W.U]::mouse_event(1,-1,0,0,0); ` +
        `Start-Sleep -Milliseconds 300; ` +
        `(New-Object -ComObject WScript.Shell).SendKeys('{ENTER}')` +
        `"`,
      darwin: "caffeinate -u -t 1",
      linux: "xdotool key Return",
    }),
  },
  LOGOUT: {
    risk: "medium", permission: "logoutDevice", label: "Logging out.",
    exec: run({
      win32: "shutdown /l",
      darwin: "osascript -e 'tell application \"System Events\" to log out'",
      linux: "gnome-session-quit --no-prompt || loginctl terminate-session $XDG_SESSION_ID",
    }),
  },

  RESTART: {
    risk: "high", permission: "restartDevice", label: "Restarting the computer.",
    requiresConfirm: true,
    exec: run({
      win32: "shutdown /r /t 5",
      darwin: "osascript -e 'tell app \"System Events\" to restart'",
      linux: "systemctl reboot",
    }),
  },
  SHUTDOWN: {
    risk: "high", permission: "shutdownDevice", label: "Shutting down the computer.",
    requiresConfirm: true,
    exec: run({
      win32: "shutdown /s /t 5",
      darwin: "osascript -e 'tell app \"System Events\" to shut down'",
      linux: "systemctl poweroff",
    }),
  },

  SYSTEM_INFO: {
    risk: "low", permission: "systemInfo", label: "Here's your system info.",
    exec: () =>
      Promise.resolve(
        `Platform: ${os.type()} ${os.release()}, CPU cores: ${os.cpus().length}, ` +
        `Total memory: ${(os.totalmem() / 1e9).toFixed(1)} GB, Uptime: ${Math.round(os.uptime() / 60)} min.`
      ),
  },
};

module.exports = { COMMANDS, platform };
