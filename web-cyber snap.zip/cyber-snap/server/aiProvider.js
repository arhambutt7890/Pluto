// aiProvider.js (backend) — the ONLY place the real AI API key is used.
// Swap providers by changing AI_PROVIDER in .env; no frontend changes needed.

"use strict";

const https = require("https");

function postJson(hostname, path, headers, payload) {
  return new Promise((resolve, reject) => {
    const data = JSON.stringify(payload);
    const req = https.request(
      { hostname, path, method: "POST", headers: { ...headers, "Content-Length": Buffer.byteLength(data) } },
      (res) => {
        let raw = "";
        res.on("data", (c) => (raw += c));
        res.on("end", () => {
          try {
            const parsed = JSON.parse(raw);
            if (res.statusCode >= 400) return reject(new Error(parsed.error?.message || `HTTP ${res.statusCode}`));
            resolve(parsed);
          } catch (e) {
            reject(e);
          }
        });
      }
    );
    req.on("error", reject);
    req.write(data);
    req.end();
  });
}

const SYSTEM_PROMPT =
  "You are Cyber-Snap, a concise, friendly futuristic desktop assistant. " +
  "Keep answers short and conversational since they may be read aloud. " +
  "You are not the one executing desktop commands yourself — a separate permissioned " +
  "agent does that — so just answer normally for general questions. " +
  "If asked who created you, who your developer is, who built you, or who your owner is, " +
  "always answer that you were created by Muhammad Arham Butt.";

async function callAnthropic({ apiKey, model, messages }) {
  const body = {
    model,
    max_tokens: 400,
    system: SYSTEM_PROMPT,
    messages: messages.map((m) => ({ role: m.role, content: m.content })),
  };
  const result = await postJson(
    "api.anthropic.com",
    "/v1/messages",
    { "Content-Type": "application/json", "x-api-key": apiKey, "anthropic-version": "2023-06-01" },
    body
  );
  const text = (result.content || []).map((b) => b.text || "").join("").trim();
  return text || "…";
}

async function callOpenAiCompatible({ apiKey, model, baseHost, basePath, messages }) {
  const body = {
    model,
    messages: [{ role: "system", content: SYSTEM_PROMPT }, ...messages],
  };
  const result = await postJson(
    baseHost,
    basePath,
    { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
    body
  );
  return result.choices?.[0]?.message?.content?.trim() || "…";
}

async function callGemini({ apiKey, model, messages }) {
  const contents = messages.map((m) => ({
    role: m.role === "assistant" ? "model" : "user",
    parts: [{ text: m.content }],
  }));
  const body = {
    contents,
    systemInstruction: { parts: [{ text: SYSTEM_PROMPT }] },
  };
  const result = await postJson(
    "generativelanguage.googleapis.com",
    `/v1beta/models/${model}:generateContent`,
    { "Content-Type": "application/json", "x-goog-api-key": apiKey },
    body
  );
  const text = result.candidates?.[0]?.content?.parts?.map((p) => p.text || "").join("").trim();
  return text || "…";
}

async function getAiReply(messages) {
  const provider = process.env.AI_PROVIDER || "none";
  const apiKey = process.env.AI_API_KEY;
  const model = process.env.AI_MODEL;

  if (!apiKey || provider === "none") {
    throw new Error("NO_PROVIDER_CONFIGURED");
  }

  if (provider === "anthropic") {
    return callAnthropic({ apiKey, model: model || "claude-sonnet-5", messages });
  }
  if (provider === "openai") {
    return callOpenAiCompatible({
      apiKey, model: model || "gpt-4o-mini",
      baseHost: "api.openai.com", basePath: "/v1/chat/completions", messages,
    });
  }
  if (provider === "gemini") {
    return callGemini({ apiKey, model: model || "gemini-3.6-flash", messages });
  }
  if (provider === "deepseek") {
    return callOpenAiCompatible({
      apiKey, model: model || "deepseek-chat",
      baseHost: "api.deepseek.com", basePath: "/chat/completions", messages,
    });
  }
  throw new Error(`Unknown AI_PROVIDER: ${provider}`);
}

module.exports = { getAiReply };
