// server.js (backend HTTP wrapper) — RECONSTRUCTED FILE.
//
// This file was never pasted in full into the chat that produced this
// project — only its console output and require path were confirmed
// ("Cyber-Snap AI backend listening on http://127.0.0.1:8788",
// "AI provider configured.", errors surfacing from aiProvider.js:19).
// It is rebuilt here to match that behavior and the /api/chat contract
// expected by frontend/js/aiProvider.js: POST {messages} -> {reply}.
// Swap in your real version if it differs from this reconstruction.
//
// Loads server/.env (AI_PROVIDER, AI_API_KEY, AI_MODEL,
// CYBERSNAP_SERVER_PORT) and never exposes the API key to the frontend —
// the frontend only ever talks to this local proxy.

"use strict";

const http = require("http");
const fs = require("fs");
const path = require("path");
const { getAiReply } = require("./aiProvider");

// ---------- Minimal .env loader (no dependencies) ----------
function loadEnv() {
  const envPath = path.join(__dirname, ".env");
  if (!fs.existsSync(envPath)) return;
  const lines = fs.readFileSync(envPath, "utf8").split("\n");
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const eq = trimmed.indexOf("=");
    if (eq === -1) continue;
    const key = trimmed.slice(0, eq).trim();
    const value = trimmed.slice(eq + 1).trim();
    if (key && !(key in process.env)) {
      process.env[key] = value;
    }
  }
}
loadEnv();

const PORT = process.env.CYBERSNAP_SERVER_PORT || 8788;
const HOST = "127.0.0.1"; // localhost only

function sendJson(res, status, body) {
  const data = JSON.stringify(body);
  res.writeHead(status, {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*", // local-only server; browser same-origin not guaranteed
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  });
  res.end(data);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let raw = "";
    req.on("data", (chunk) => {
      raw += chunk;
      if (raw.length > 2e6) req.destroy(); // guard against absurd payloads
    });
    req.on("end", () => {
      if (!raw) return resolve({});
      try { resolve(JSON.parse(raw)); } catch (e) { reject(e); }
    });
    req.on("error", reject);
  });
}

const server = http.createServer(async (req, res) => {
  if (req.method === "OPTIONS") return sendJson(res, 204, {});

  const url = new URL(req.url, `http://${HOST}:${PORT}`);

  if (url.pathname === "/api/chat" && req.method === "POST") {
    let body;
    try {
      body = await readBody(req);
    } catch {
      return sendJson(res, 400, { message: "Invalid request body." });
    }

    const messages = Array.isArray(body.messages) ? body.messages : [];

    try {
      const reply = await getAiReply(messages);
      return sendJson(res, 200, { reply });
    } catch (err) {
      console.error(err);
      // Surfacing as 502 so the frontend's fallback (canned responses) kicks in
      // cleanly, whether the failure is a missing provider config, a bad key,
      // a rate limit, or a network issue talking to the upstream provider.
      return sendJson(res, 502, { message: "AI provider request failed." });
    }
  }

  sendJson(res, 404, { message: "Not found." });
});

server.listen(PORT, HOST, () => {
  console.log(`Cyber-Snap AI backend listening on http://${HOST}:${PORT}`);
  if (process.env.AI_API_KEY && process.env.AI_PROVIDER) {
    console.log("AI provider configured.");
  } else {
    console.log("WARNING: no AI provider configured — check server/.env");
  }
});
